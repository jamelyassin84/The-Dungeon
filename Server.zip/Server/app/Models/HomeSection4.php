<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HomeSection4 extends Model
{
    use HasFactory;

    protected $fillable = [
        'isSectionEnabled',
        'isPricingEnabled',
        'title',
        'body',
        'notice',
        'uri',
    ];

    protected $casts = [
        'isSectionEnabled' => 'boolean',
        'isPricingEnabled' => 'boolean',
    ];
}
