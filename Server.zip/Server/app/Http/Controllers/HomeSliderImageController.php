<?php

namespace App\Http\Controllers;

use App\Models\HomeSliderImage;
use App\Http\Requests\StoreHomeSliderImageRequest;
use App\Http\Requests\UpdateHomeSliderImageRequest;
use Illuminate\Http\Request;

class HomeSliderImageController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum')->except('index');
    }

    public function index()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
