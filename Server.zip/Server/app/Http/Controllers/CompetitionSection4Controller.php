<?php

namespace App\Http\Controllers;

use App\Models\CompetitionSection4;
use App\Http\Requests\StoreCompetitionSection4Request;
use App\Http\Requests\UpdateCompetitionSection4Request;
use Illuminate\Http\Request;

class CompetitionSection4Controller extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum')->except('index');
    }

    public function index()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
