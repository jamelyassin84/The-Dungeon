<?php

namespace App\Http\Controllers;

use App\Models\RuleValue;
use Illuminate\Http\Request;

class RuleValueController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum')->except('index');
    }

    public function index()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
